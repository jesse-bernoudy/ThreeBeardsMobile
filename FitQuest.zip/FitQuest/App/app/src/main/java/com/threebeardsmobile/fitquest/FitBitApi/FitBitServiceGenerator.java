package com.threebeardsmobile.fitquest.FitBitApi;

/**
 * Created by Jesse on 5/28/2016.
 */
public class FitBitServiceGenerator {
    public static final String API_LOGIN_URL = "https://www.fitbit.com/oauth2/";
    public static final String API_LOGOUT_URL = "https://api.fitbit.com/oauth2/";
    public static final String USER_BASE_URL = "https://api.fitbit.com/1/user/";
}
